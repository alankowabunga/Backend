package com.ginmao.repository;

import com.ginmao.domain.GtPerson;
import org.springframework.stereotype.Repository;

@Repository
public interface GtPersonRepository extends BaseRepository<GtPerson,String>{
}
